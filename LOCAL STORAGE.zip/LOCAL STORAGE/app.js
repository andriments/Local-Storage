//Variables
const message = document.getElementById('message'),
      sendBtn = document.getElementById('sendBtn'),
      lsoutput = document.getElementById('lsoutput'),
      output = document.querySelector('lsoutput');
      
  //Listeners
  loadEventListeners();
  function loadEventListeners() {
    message.addEventListener('click',lsoutput);
    lsoutput.addEventListener('click',removeMessage);
  }
      

      sendBtn.onclick = function () {
          const key = message.value;
          const output = lsoutput.value;
         console.log(key);
         console.log(lsoutput);
          
        
          if(key){
              localStorage.setItem(key,lsoutput);
              location.reload();
          }
           
      };
      

      for(let i = 0; i < localStorage.length; i++){
          const key = localStorage.key(i);
          const value = localStorage.getItem(key);

          lsoutput.innerHTML += `${key}</br>`;
      }
      if(typeof localStorage !== "undifiend" ){
      
      }else{

      }
      document.getElementById("lsoutput").addEventListener('click', function(){
          console.log("click the button");

      });

        // Remove

      function removeMessage(e) {
        if(e.target.classlist.contains('remove')){
          e.target.parentElement.parentElement.remove();
        }
      }



      